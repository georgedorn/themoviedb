from setuptools import setup

setup(name='themoviedb',
      packages=['themoviedb']
)